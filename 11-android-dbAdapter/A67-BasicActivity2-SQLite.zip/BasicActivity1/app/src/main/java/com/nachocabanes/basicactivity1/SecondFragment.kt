package com.nachocabanes.basicactivity1

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.nachocabanes.basicactivity1.databinding.FragmentSecondBinding

/**
 * A simple [Fragment] subclass as the second destination in the navigation.
 */
class SecondFragment : Fragment() {

    private var _binding: FragmentSecondBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    lateinit var mascotasDBHelper: miSQLiteHelper

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentSecondBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mascotasDBHelper = miSQLiteHelper(view.context)

        binding.btGuardar.setOnClickListener {

            if (binding.etNombre.text.isNotBlank() &&
                binding.etRaza.text.isNotBlank()
            ) {
                mascotasDBHelper.anyadir(
                    binding.etNombre.text.toString(),
                    binding.etRaza.text.toString()
                )
                binding.etNombre.text.clear()
                binding.etRaza.text.clear()
                Toast.makeText(
                    view.context, "Guardado",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    view.context, "No se ha podido guardar",
                    Toast.LENGTH_LONG
                ).show()
            }
            findNavController().navigate(R.id.action_SecondFragment_to_FirstFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}