package com.nachocabanes.basicactivity1

import android.content.Context
import android.database.Cursor
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast

import com.nachocabanes.basicactivity1.placeholder.PlaceholderContent.PlaceholderItem
import com.nachocabanes.basicactivity1.databinding.FragmentItemBinding

class MyMascotaRecyclerViewAdapter  :
    RecyclerView.Adapter<MyMascotaRecyclerViewAdapter.ViewHolder>(){

    private lateinit var context: Context
    private lateinit var cursor: Cursor

    fun  RecyclerViewAdapterMascotas(context: Context, cursor: Cursor) {
        this.context = context
        this.cursor = cursor
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return ViewHolder( inflater.inflate(
            R.layout.fragment_item,
            parent,
            false
        ))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        cursor.moveToPosition(position)
        holder.tvNombre.text = cursor.getString(1)
        holder.tvRaza.text = cursor.getString(2)
    }

    override fun getItemCount(): Int {
        return cursor.count
    }

    inner class ViewHolder: RecyclerView.ViewHolder {

        val tvNombre: TextView
        val tvRaza: TextView

        constructor(view: View) : super(view) {
            var bindingItemsRV = FragmentItemBinding.bind(view)

            this.tvNombre = bindingItemsRV.tvNombreRV
            this.tvRaza = bindingItemsRV.tvRazaRV

            view.setOnClickListener {
                Toast.makeText(context,
                    "Escogido: ${this.tvNombre.text}",
                    Toast.LENGTH_SHORT).show()
            }

        }

    }


}
/*
class MyMascotaRecyclerViewAdapter(
    private val values: List<PlaceholderItem>
) : RecyclerView.Adapter<MyMascotaRecyclerViewAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        return ViewHolder(
            FragmentItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = values[position]
        holder.idView.text = item.id
        holder.contentView.text = item.content
    }

    override fun getItemCount(): Int = values.size

    inner class ViewHolder(binding: FragmentItemBinding) : RecyclerView.ViewHolder(binding.root) {
        val idView: TextView = binding.itemNumber
        val contentView: TextView = binding.content

        override fun toString(): String {
            return super.toString() + " '" + contentView.text + "'"
        }
    }

}

 */