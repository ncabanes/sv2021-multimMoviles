package com.nachocabanes.basicactivity1

import android.app.AlertDialog
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.os.CountDownTimer
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.getSystemService
import com.google.android.material.snackbar.Snackbar
import com.nachocabanes.basicactivity1.databinding.DialogoModificarBinding

import com.nachocabanes.basicactivity1.placeholder.PlaceholderContent.PlaceholderItem
import com.nachocabanes.basicactivity1.databinding.FragmentItemBinding

class MyMascotaRecyclerViewAdapter  :
    RecyclerView.Adapter<MyMascotaRecyclerViewAdapter.ViewHolder>(){

    private lateinit var context: Context
    private lateinit var cursor: Cursor
    private lateinit var dbHelper: miSQLiteHelper
    private lateinit var bindingDialogo: DialogoModificarBinding

    fun  MyMascotaRecyclerViewAdapter(context: Context, cursor: Cursor, helper:miSQLiteHelper) {
        this.context = context
        this.cursor = cursor
        this.dbHelper = helper
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return ViewHolder( inflater.inflate(
            R.layout.fragment_item,
            parent,
            false
        ))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        cursor.moveToPosition(position)
        holder.tvNombre.text = cursor.getString(1)
        holder.tvRaza.text = cursor.getString(2)

        holder.tvNombre.tag = cursor.getInt(0)

        holder.itemView.setOnLongClickListener {
            mostrarMenu(holder.itemView, position)
            true
        }
    }

    override fun getItemCount(): Int {
        return cursor.count
    }

    fun mostrarMenu(v: View, position: Int) {
        PopupMenu(v.context, v ).apply {
            inflate(R.menu.menu_mascotas)
            setOnMenuItemClickListener {
                when(it!!.itemId) {
                    R.id.opcModificar -> {
                        ModificarRegistro(position, v)
                        true
                    }
                    R.id.opcBorrar -> {
                        BorrarRegistro(position, v)
                        true
                    }
                    else -> false
                }
            }
        }.show()
    }

    private fun BorrarRegistro(position: Int, vista: View) {
        cursor.moveToPosition(position)
        val nombre = cursor.getString(1)
        val raza = cursor.getString(2)
        val id = cursor.getInt(0)

        val builder = AlertDialog.Builder(context)
        builder.setTitle("Borrar")
        builder.setMessage("Confirma que deseas borrar $nombre ($id)")
        builder.setPositiveButton(android.R.string.ok) { dialog, which ->
            val cantidad = dbHelper.borrar(id)
            if (cantidad > 0) {
                Toast.makeText(
                    context,
                    "Borrado",
                    Toast.LENGTH_SHORT
                ).show()

                // Y volvemos a generar el cursor
                cursor = dbHelper.readableDatabase.rawQuery(
                    "SELECT * FROM mascotas ORDER BY nombre",
                    null
                )
                //notifyDataSetChanged()
                notifyItemRemoved(position)
            }
            else
                Toast.makeText(context,
                    "No borrado",
                    Toast.LENGTH_LONG).show()
        }
        builder.setNegativeButton(android.R.string.cancel, null)
        builder.show()
    }

    private fun ModificarRegistro(position: Int, vista: View) {
        cursor.moveToPosition(position)
        val nombre = cursor.getString(1)
        val raza = cursor.getString(2)
        val id = cursor.getInt(0)

        val inflater = LayoutInflater.from(context)
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Modificar")

        bindingDialogo = DialogoModificarBinding.inflate(inflater)

        builder.setView(inflater.inflate(R.layout.dialogo_modificar, null))
        // Cuidado: no actualiza los valores de los EditText (¿todavía?)
        bindingDialogo.etNombre.setText(nombre)
        bindingDialogo.etRaza.setText(raza)

        builder.setPositiveButton(android.R.string.ok) { dialog, which ->

            val nuevoNombre = bindingDialogo.etNombre.text.toString()
            val nuevaRaza = bindingDialogo.etRaza.text.toString()
            // Cuidado: no actualiza en la tabla (¿todavía?)
            dbHelper.modificar(id, nuevoNombre, nuevaRaza)

            // Y volvemos a generar el cursor
            cursor = dbHelper.readableDatabase.rawQuery(
                "SELECT * FROM mascotas ORDER BY nombre",
                null
            )
            //notifyDataSetChanged()
            notifyItemChanged(position)

            Toast.makeText(
                context,
                "Modificado",
                Toast.LENGTH_SHORT
            ).show()
        }
        builder.setNegativeButton(android.R.string.cancel, null)
        builder.show()
    }

    inner class ViewHolder: RecyclerView.ViewHolder {
        val tvNombre: TextView
        val tvRaza: TextView

        constructor(view: View) : super(view) {
            var bindingItemsRV = FragmentItemBinding.bind(view)

            this.tvNombre = bindingItemsRV.tvNombreRV
            this.tvRaza = bindingItemsRV.tvRazaRV
        }
    }
}
