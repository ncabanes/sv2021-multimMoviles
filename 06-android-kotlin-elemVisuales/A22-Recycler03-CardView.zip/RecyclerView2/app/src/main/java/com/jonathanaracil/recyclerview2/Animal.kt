package com.jonathanaracil.recyclerview2

data class Animal(
    val nombre: String,
    val latin: String,
    val imageAnimal: Int
)
