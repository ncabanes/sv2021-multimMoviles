package com.nachocabanes.recycler02

data class Animal(
    val nombre: String,
    val nombreLatin: String,
    val id: Integer
)
